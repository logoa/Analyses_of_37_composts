# Overview over the different files in the files in the folder:C:\Users\anja.logo\ownCloud\Kompostmikrobio\Statistics\Fungi_BLW2_24\Fungi_37\data

# In general
- Design_BLW2.csv				Experimental design: all composts
- Key_treatment_compostID.csv			New ID of composts: all composts
- meta_data_compost_BLW_without_errors.csv	Compost meta data: all composts

# ASV tables
- asv.F.BLW2.txt				ASV table unrarefied, non-fungal sequences, NTC discarded, without K27 and K37
- asv.F.r.txt					ASV table unrarefied, non-fungal sequences, NTC discarded, without K6, K10, K17, K27 and K37
- ISS.F.BLW2.txt				ASV table rarefied, without compost exclude + K19 (not enough sequences)
- ISS.F.BLW2.comp.txt				ASV table rarefied, without compost exclude + K19 (not enough sequences)+ peat substrates
- ISS.rob.avg.txt				ASV table rarefied, averaged over replicates, only robustly identfied (3/4), without compost exclude + K19
- ISS.rob.comp.avg.txt				ASV table rarefied, averaged over replicates, , only robustly identfied (3/4), without peat
- ISS.rob.comp.txt				ASV table rarefied, only robustly identified (3/4), without peat
- ISS.rob.txt					ASV table rarefied, only robustly identified (3/4)
- asv.rob.comp.avg.txt				ASV table unrarefied, averaged over replicates, only robustly identified (3/4) but original count!

# Tax tables
- tax.F.BLW2.txt				Taxonomic file without fungi all samples
- tax-F.r.txt					Taxonomic file only with 37 composts + peat substrate

# Alpha diversity
- df_BLW2_div.csv				Compost meta data with alpha diversity: K6, K10, K17, K19, K27 and K37 excluded
- ISS.alpha.F.BLW2.csv				Alpha diversity metrics for all samples: K6, K10, K17, K19, K27 and K37 excluded

# Beta diversity
- ISS.bray.txt					Bray curtis dissimliarity for all samples: K6, K10, K17, K19, K27 and K37 excluded
- ISS.bray.avg.txt				Bray curtis dissimliarity averaged of the replicates: K6, K10, K17, K19, K27 and K37 excluded
- ISS.jac.txt					Jaccard dissimliarity for all samples: K6, K10, K17, K19, K27 and K37 excluded
- ISS.jac.avg.txt				Jaccard dissimliarity averaged of the replicates: K6, K10, K17, K19, K27 and K37 excluded
